package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedContentDao {
    @Query("SELECT * FROM saved_content ORDER BY timestamp DESC")
    fun getAllSavedFlow(): Flow<List<SavedContent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaved(content: SavedContent): Long

    @Delete
    suspend fun deleteSaved(content: SavedContent)

    @Query("DELETE FROM saved_content WHERE id = :id")
    suspend fun deleteById(id: Int)
}
