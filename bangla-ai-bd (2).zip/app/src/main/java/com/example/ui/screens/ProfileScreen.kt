package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BanglaGoldAccent
import com.example.ui.theme.BanglaGreenPrimary
import com.example.ui.theme.BanglaTealLight
import com.example.ui.viewmodel.BanglaAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: BanglaAiViewModel) {
    val userConfig by viewModel.userConfig.collectAsState()
    val savedContents by viewModel.savedContents.collectAsState()

    val currentPlan = userConfig?.subscriptionPlan ?: "free"
    val usedCount = userConfig?.dailyUsageCount ?: 0
    val activeUserName = userConfig?.currentUserName ?: "ক্রিয়াশীল উদ্যোক্তা"
    val activeUserEmail = userConfig?.currentUserEmail ?: "user@banglaai.bd"

    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }

    // Sync input local states when userConfig is loaded
    LaunchedEffect(userConfig) {
        userConfig?.let {
            nameInput = it.currentUserName
            emailInput = it.currentUserEmail
        }
    }

    val planLimit = when (currentPlan) {
        "free" -> 10
        "basic" -> 50
        "pro" -> 500
        "business" -> 999999
        else -> 10
    }

    val usagePercentage = if (planLimit == 999999) {
        0f
    } else {
        (usedCount.toFloat() / planLimit.toFloat()).coerceIn(0f, 1f)
    }

    val animatedSweep by animateFloatAsState(targetValue = usagePercentage * 360f, label = "SweepAngle")
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("profile_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Avatar & Badge Title
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Circle Avatar
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), shape = CircleShape)
                        .border(1.5.dp, MaterialTheme.colorScheme.primary, shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activeUserName.take(2).uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = activeUserName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = activeUserEmail,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )

                Badge(
                    containerColor = if (currentPlan == "free") Color.Gray else BangorGoldOrPrimary(currentPlan),
                    contentColor = Color.White,
                    modifier = Modifier.size(90.dp, 22.dp)
                ) {
                    Text(currentPlan.uppercase() + " MEMBER", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Circular Limit Gauge
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "📊 আজকের কন্টেন্ট ইউসেজ লিমিট",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                )

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(130.dp)
                ) {
                    val trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    val progressColor = if (usagePercentage >= 0.9f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Draw Background Track Circle
                        drawCircle(
                            color = trackColor,
                            style = Stroke(width = 10.dp.toPx())
                        )

                        // Draw Progress Arc
                        if (planLimit != 999999) {
                            drawArc(
                                color = progressColor,
                                startAngle = -90f,
                                sweepAngle = animatedSweep,
                                useCenter = false,
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                        } else {
                            // Infinite glowing ring
                            drawArc(
                                color = BanglaGoldAccent,
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (planLimit == 999999) {
                            Text(
                                text = "∞",
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                color = BanglaGoldAccent
                            )
                            Text(
                                text = "আনলিমিটেড কন্টেন্ট",
                                fontSize = 9.sp,
                                color = Color.Gray
                            )
                        } else {
                            Text(
                                text = "$usedCount / $planLimit",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val remaining = planLimit - usedCount
                            Text(
                                text = "বাকি আছে: ${if (remaining < 0) 0 else remaining}",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                // Info Rows
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("সংরক্ষিত কন্টেন্ট", fontSize = 11.sp, color = Color.Gray)
                        Text("${savedContents.size} টি", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(24.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("পেমেন্ট অবস্থান", fontSize = 11.sp, color = Color.Gray)
                        Text(if (currentPlan == "free") "ফ্রি ট্রায়াল" else "পরিশোধিত (Paid)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                if (usedCount >= planLimit && currentPlan == "free") {
                    Text(
                        text = "⚠️ আপনার আজকের ফ্রী ব্যবহারের লিমিট শেষ হয়েছে! অনুগ্রহ করে Subscription ট্যাব থেকে প্যাকেজ পরিবর্তন করুন।",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Profile Form Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "⚙️ প্রোফাইল সেটিংস পরিবর্তন করুন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("ক্রিয়েটর বা ব্রান্ড নাম", fontSize = 12.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("profile_name_field")
                )

                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it },
                    label = { Text("ইমেইল অ্যাড্রেস", fontSize = 12.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("profile_email_field")
                )

                Button(
                    onClick = {
                        if (nameInput.isNotBlank() && emailInput.isNotBlank()) {
                            viewModel.updateProfile(nameInput, emailInput)
                        } else {
                            viewModel.triggerToast("ফর্মটি সঠিকভাবে পূরণ করুন")
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("save_profile_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Save", Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("সেটিংস সেভ করুন", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Debug/Prototyping Tools Card (Strictly useful for testing)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.1f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "🛠️ প্রোটোটাইপ ইভ্যালুয়েশন কুইক টুলস",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
                Text(
                    text = "সহজে টেস্ট করতে এই বাটনটি দিয়ে আজকের ব্যবহার করা কাউন্টার রিসেট করতে পারবেন।",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                Button(
                    onClick = {
                        // Directly set usage count to 0 in ViewModel context
                        viewModel.upgradePlan(currentPlan) // Trigger plan reloads and resets limits count to 0!
                        viewModel.triggerToast("ব্যবহারের লিমিট ০ তে রিসেট হয়েছে! 🔄")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("reset_usage_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset", Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("আজকের কাউন্টার রিসেট করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun BangorGoldOrPrimary(plan: String): Color {
    return when (plan) {
        "basic" -> BanglaGreenPrimary
        "pro" -> BanglaGoldAccent
        "business" -> BanglaTealLight
        else -> BanglaGreenPrimary
    }
}
