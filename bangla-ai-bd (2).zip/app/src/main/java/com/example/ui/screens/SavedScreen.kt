package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.SavedContent
import com.example.ui.theme.BanglaGoldAccent
import com.example.ui.viewmodel.BanglaAiViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SavedScreen(viewModel: BanglaAiViewModel) {
    val context = LocalContext.current
    val savedItems by viewModel.savedContents.collectAsState()

    if (savedItems.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
                .testTag("saved_empty_state"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FavoriteBorder,
                    contentDescription = "Empty collection",
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = "সংগ্রহশালা ফাঁকা! 📁",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "আপনার জেনারেট করা ডেসক্রিপশন বা ক্যাপশনগুলো পছন্দ হলে 'হৃদয়' আইকনে ক্লিক করে এখানে সেভ করে রাখতে পারবেন।",
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("saved_list_view"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "সংরক্ষিত কন্টেন্ট সংকলন (${savedItems.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            items(savedItems, key = { it.id }) { item ->
                SavedContentCard(
                    item = item,
                    onCopy = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Saved Content", item.resultText)
                        clipboard.setPrimaryClip(clip)
                        viewModel.triggerToast("ক্লিপবোর্ডে কপি করা হয়েছে!")
                    },
                    onDelete = {
                        viewModel.deleteSavedItem(item)
                    }
                )
            }
        }
    }
}

@Composable
fun SavedContentCard(
    item: SavedContent,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    val featureEmojiAndTitle = when (item.featureName) {
        "caption" -> Pair("📘", "ক্যাপশন")
        "hashtags" -> Pair("🏷️", "হ্যাশট্যাগ")
        "description" -> Pair("📦", "প্রোডাক্ট বিবরণী")
        "youtube" -> Pair("🎬", "ইউটিউব টাইটেল")
        "adcopy" -> Pair("💎", "মার্কেটিং অ্যাড কপি")
        "blog" -> Pair("📝", "ব্লগ ও স্ক্রিপ্ট")
        else -> Pair("⚙️", "জেনারেল কন্টেন্ট")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("saved_card_${item.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = featureEmojiAndTitle.first, fontSize = 20.sp)
                    Text(
                        text = featureEmojiAndTitle.second,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(36.dp).testTag("saved_copy_btn_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Copy text",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(36.dp).testTag("saved_delete_btn_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete item",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Subject descriptor
            Text(
                text = "কীওয়ার্ড: \"${item.topic}\"",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Text text
            Text(
                text = item.resultText,
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
