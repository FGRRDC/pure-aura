package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_config")
data class UserConfig(
    @PrimaryKey val id: Int = 1,
    val subscriptionPlan: String = "free", // free, basic, pro, business
    val dailyUsageCount: Int = 0,
    val lastResetDate: String = "", // YYYY-MM-DD
    val currentUserName: String = "উদ্যোক্তা", // Default name
    val currentUserEmail: String = "user@banglaai.bd"
)
