package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.SavedContent
import com.example.data.database.UserConfig
import com.example.data.model.GenerateContentRequest
import com.example.data.network.GeminiApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class BanglaAiViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val userConfigDao = db.userConfigDao()
    private val savedContentDao = db.savedContentDao()
    private val apiService = GeminiApiService.create()

    // UI States
    val userConfig: StateFlow<UserConfig?> = userConfigDao.getUserConfigFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val savedContents: StateFlow<List<SavedContent>> = savedContentDao.getAllSavedFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Live Generation States
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _lastGeneratedText = MutableStateFlow("")
    val lastGeneratedText: StateFlow<String> = _lastGeneratedText.asStateFlow()

    private val _errorMessage = MutableStateFlow("")
    val errorMessage: StateFlow<String> = _errorMessage.asStateFlow()

    // Form inputs
    val selectedFeature = MutableStateFlow("caption") // caption, hashtags, description, youtube, adcopy, blog
    val inputText = MutableStateFlow("")

    val premiumTone = MutableStateFlow("আকর্ষণীয় ও প্রফেশনাল")
    val premiumTargetAudience = MutableStateFlow("বাংলাদেশী তরুন ও উদ্যোক্তা")
    val blogType = MutableStateFlow("blog") // blog, script, article
    val blogWordCount = MutableStateFlow("৫০০")

    // Simple toast channel to communicate with UI
    private val _toastEvent = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    init {
        // Enforce daily limit check and reset count if date differs
        viewModelScope.launch(Dispatchers.IO) {
            val today = getTodayDateString()
            val config = userConfigDao.getUserConfig()
            if (config == null) {
                userConfigDao.insertUserConfig(
                    UserConfig(
                        subscriptionPlan = "free",
                        dailyUsageCount = 0,
                        lastResetDate = today,
                        currentUserName = "ক্রিয়েটর",
                        currentUserEmail = "creator@banglaai.bd"
                    )
                )
            } else if (config.lastResetDate != today) {
                userConfigDao.insertUserConfig(
                    config.copy(dailyUsageCount = 0, lastResetDate = today)
                )
            }
        }
    }

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun triggerToast(msg: String) {
        _toastEvent.tryEmit(msg)
    }

    fun updateProfile(name: String, email: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val config = userConfigDao.getUserConfig() ?: return@launch
            userConfigDao.insertUserConfig(config.copy(currentUserName = name, currentUserEmail = email))
            _toastEvent.tryEmit("প্রোফাইল আপডেট হয়েছে!")
        }
    }

    fun upgradePlan(plan: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val config = userConfigDao.getUserConfig() ?: return@launch
            userConfigDao.insertUserConfig(config.copy(subscriptionPlan = plan, dailyUsageCount = 0))
            _toastEvent.tryEmit("প্ল্যান সফলভাবে $plan এ আপগ্রেড করা হয়েছে!")
        }
    }

    fun deleteSavedItem(item: SavedContent) {
        viewModelScope.launch(Dispatchers.IO) {
            savedContentDao.deleteSaved(item)
            _toastEvent.tryEmit("কালেকশন থেকে বাদ দেওয়া হয়েছে")
        }
    }

    fun saveContentLocally(feature: String, topic: String, text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            if (text.isEmpty()) return@launch
            savedContentDao.insertSaved(
                SavedContent(
                    featureName = feature,
                    topic = topic,
                    resultText = text
                )
            )
            _toastEvent.tryEmit("কালেকশনে সেভ করা হয়েছে! ❤️")
        }
    }

    fun generateContent() {
        val currentInput = inputText.value.trim()
        if (currentInput.isEmpty()) {
            _toastEvent.tryEmit("দয়া করে বিষয়বস্তু বা কীওয়ার্ড লিখুন")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isGenerating.value = true
            _errorMessage.value = ""

            val config = userConfigDao.getUserConfig() ?: return@launch
            val today = getTodayDateString()

            // 1. Check/perform date resets
            var activeConfig = config
            if (config.lastResetDate != today) {
                activeConfig = config.copy(dailyUsageCount = 0, lastResetDate = today)
                userConfigDao.insertUserConfig(activeConfig)
            }

            // 2. Validate usage limits
            val limit = when (activeConfig.subscriptionPlan) {
                "free" -> 10
                "basic" -> 50
                "pro" -> 500
                "business" -> 999999
                else -> 10
            }

            // Verify premium features requirements
            val isPremiumFeature = selectedFeature.value == "adcopy" || selectedFeature.value == "blog"
            if (isPremiumFeature && activeConfig.subscriptionPlan == "free") {
                _errorMessage.value = "⚠️ এটি একটি প্রিমিয়াম ফিচার। প্ল্যান আপগ্রেড করুন!"
                _isGenerating.value = false
                return@launch
            }

            if (activeConfig.dailyUsageCount >= limit && activeConfig.subscriptionPlan == "free") {
                _errorMessage.value = "⚠️ আজকের লিমিট শেষ! প্রিমিয়াম প্ল্যানে আপগ্রেড করুন।"
                _isGenerating.value = false
                return@launch
            }

            // 3. Formulate Prompt
            val prompt = buildCustomPrompt(currentInput)

            // 4. API Call
            try {
                val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    _errorMessage.value = "⚠️ এপিআই কী (GEMINI_API_KEY) পাওয়া যায়নি! AI Studio UI-এর Secrets প্যানেলে সেট করুন।"
                    _isGenerating.value = false
                    return@launch
                }

                val requestBody = GenerateContentRequest(
                    contents = listOf(
                        com.example.data.model.Content(
                            parts = listOf(com.example.data.model.Part(text = prompt))
                        )
                    )
                )

                val response = apiService.generateContent(apiKey, requestBody)
                val rawText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (rawText != null) {
                    _lastGeneratedText.value = rawText
                    // Increment count
                    userConfigDao.insertUserConfig(
                        activeConfig.copy(dailyUsageCount = activeConfig.dailyUsageCount + 1)
                    )
                } else {
                    _errorMessage.value = "সার্ভার থেকে কোনো তথ্য পাওয়া যায়নি। অনুগ্রহ করে পুনরায় চেষ্টা করুন।"
                }

            } catch (e: Exception) {
                _errorMessage.value = "নেটওয়ার্ক সমস্যা: ${e.localizedMessage ?: "সংযোগ ব্যর্থ হয়েছে"}"
            } finally {
                _isGenerating.value = false
            }
        }
    }

    private fun buildCustomPrompt(topic: String): String {
        return when (selectedFeature.value) {
            "caption" -> {
                "তুমি বাংলাদেশের সেরা মার্কেটিং বিশেষজ্ঞ। \"$topic\" নিয়ে একটি আকর্ষণীয় Facebook পোস্টের ক্যাপশন লিখো। নিয়ম: সম্পূর্ণ বাংলা ভাষায়, ট্রেন্ডি ইমোজি সহ, সুন্দর একটি Call to Action (CTA) থাকতে হবে, সর্বোচ্চ ২০০ শব্দ।"
            }
            "hashtags" -> {
                "\"$topic\" এর জন্য ১৫টি ট্রেন্ডিং ও কার্যকর হ্যাশট্যাগ দাও (বাংলা + ইংরেজি মিক্স) যেটা Facebook, TikTok এবং Instagram পোস্ট রিচ বাড়াতে কাজ করবে।"
            }
            "description" -> {
                "প্রোডাক্ট: $topic। একটি চিত্তাকর্ষক প্রোডাক্ট ডেসক্রিপশন বা বিবরণী লিখো (বাংলা ভাষায় ৩-৪ লাইনের প্রফেশনাল কন্টেন্ট, সঠিক CTA সহ যেটা বাংলাদেশী ক্রেতাদের কিনতে আকৃষ্ট করবে)।"
            }
            "youtube" -> {
                "\"$topic\" নিয়ে YouTube ভিডিওর জন্য ৭টি অত্যন্ত আকর্ষণীয় ও ক্লিকযোগ্য (Clickable & SEO Friendly) টাইটেল দাও (ইমোজি সহ চমৎকার বাংলা টাইটেল সংকলন)।"
            }
            "adcopy" -> {
                val toneStr = premiumTone.value.ifEmpty { "প্রফেশনাল" }
                val targetAudienceStr = premiumTargetAudience.value.ifEmpty { "বাংলাদেশী ক্রেতা" }
                "প্রোডাক্ট: $topic\nটোন: $toneStr\nটার্গেট অডিয়েন্স: $targetAudienceStr\n\nএকটি সম্পূর্ণ প্রিমিয়াম মার্কেটিং ফেসবুক অ্যাড কপি লিখো যাতে আছে:\n1. একটি আইক্যাচিং হেডলাইন\n2. আকর্ষণীয় বডি কপি (প্রোডাক্টের অনন্য উপকারিতাসমূহ)\n3. শক্তিশালী CTA (কি করতে হবে)\n4. একটি আকর্ষণীয় অফার বা ডিসকাউন্ট আইডিয়া\nসম্পূর্ণ বাংলা ভাষায় লিখো এবং ইমোজি চমৎকারভাবে ব্যবহার করো।"
            }
            "blog" -> {
                val typeStr = when (blogType.value) {
                    "blog" -> "ব্লগ পোস্ট"
                    "script" -> "ইউটিউব ভিডিও স্ক্রিপ্ট"
                    else -> "SEO আর্টিকেল"
                }
                val wcStr = blogWordCount.value.ifEmpty { "৫০০" }
                "\"$topic\" নিয়ে একটি বিস্তারিত প্রফেশনাল $typeStr লিখো।\nদৈর্ঘ্য: প্রায় $wcStr শব্দ\nলিখনশৈলী: বাংলাদেশী অডিয়েন্সের জন্য সহজ সাবলীল বাংলা ভাষা\nSEO রুলস: কীওয়ার্ডটি বারবার প্রাকৃতিক উপায়ে ব্যবহার করতে হবে এবং সুন্দর সাব-হেডিং (H2, H3) ব্যবহার করো।"
            }
            else -> "Give a general marketing guideline for $topic in Bengali."
        }
    }
}
