package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Part(
    val text: String
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>
)

@JsonClass(generateAdapter = true)
data class ResponsePart(
    val text: String?
)

@JsonClass(generateAdapter = true)
data class ResponseContent(
    val parts: List<ResponsePart>?
)

@JsonClass(generateAdapter = true)
data class ResponseCandidate(
    val content: ResponseContent?
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<ResponseCandidate>?
)
