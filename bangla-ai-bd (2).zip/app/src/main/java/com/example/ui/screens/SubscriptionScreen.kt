package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BanglaGoldAccent
import com.example.ui.theme.BanglaGreenPrimary
import com.example.ui.viewmodel.BanglaAiViewModel

@Composable
fun SubscriptionScreen(viewModel: BanglaAiViewModel) {
    val userConfig by viewModel.userConfig.collectAsState()
    val plan = userConfig?.subscriptionPlan ?: "free"
    
    var showPaymentDialog by remember { mutableStateOf(false) }
    var selectedPlanToBuy by remember { mutableStateOf("") }
    var priceToBuy by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("subscription_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(
                text = "💎 সাবস্ক্রিপশন প্ল্যান",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "আপনার প্রতিদিনের কাজের ওপর ভিত্তি করে সঠিক প্যাকেজটি বেছে নিন।",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Active Indicator Badge
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth().testTag("active_plan_badge")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "আপনার চলমান সাবস্ক্রিপশন প্ল্যান:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Text(
                        text = plan.uppercase() + " PACKAGE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Badge(
                    containerColor = BanglaGreenPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.size(52.dp, 28.dp)
                ) {
                    Text("ACTIVE", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Subscription Plans Catalog
        val packages = listOf(
            SubscriptionPackage(
                id = "free",
                title = "ফ্রি ট্রায়াল (Free Plan)",
                desc = "নতুন মেম্বারদের জন্য চমৎকার শুরু",
                price = "০",
                features = listOf(
                    "১০টি দৈনিক AI কন্টেন্ট জেনারেট লিমিট",
                    "চমকপ্রদ ক্যাপশন ও হ্যাশট্যাগ টুলস অ্যাক্সেস",
                    "সংগ্রহশালা সেভিং সুবিধা",
                    "স্ট্যান্ডার্ড ডেলিভারি স্পিড"
                )
            ),
            SubscriptionPackage(
                id = "basic",
                title = "বেসিক স্টার্টার (Basic Creator)",
                desc = "ছোট উদ্যোক্তা ও কন্টেন্ট রাইটারদের জন্য",
                price = "৯৯",
                features = listOf(
                    "৫০টি দৈনিক AI কন্টেন্ট জেনারেট লিমিট",
                    "সকল বেসিক টুলস ও ক্যাপশন ফুল অ্যাক্সেস",
                    "সম্পূর্ণ আনলকড কাস্টম প্রম্পটিং",
                    "অতি দ্রুত জেনারেশন স্পিড",
                    "২৪/৭ ডেডিকেটেড ব্যাকআপ সাপোর্ট"
                )
            ),
            SubscriptionPackage(
                id = "pro",
                title = "প্রো প্রফেশনাল (Pro Level Creator)",
                desc = "ফ্রীল্যান্সার ও স্যোশাল মিডিয়া ম্যানেজারদের প্রথম চয়েস",
                price = "২৪৯",
                features = listOf(
                    "৫০০টি দৈনিক AI কন্টেন্ট জেনারেট লিমিট",
                    "💎 ফেসবুক অ্যাড কপি ও প্রিমিয়াম ব্লগ রাইটার আনলকড",
                    "টোন ও টার্গেট অডিয়েন্স কাস্টমাইজেশন",
                    "আনলিমিটেড লোকাল কালেকশন সেভ সুবিধা",
                    "ভিআইপি হাই-স্পিড ডেডিকেটেড সার্ভার অ্যাক্সেস"
                )
            ),
            SubscriptionPackage(
                id = "business",
                title = "আনলিমিটেড বিজনেস (Business Elite)",
                desc = "মার্কেটিং এজেন্সি ও বড় কর্পোরেট টিমের জন্য",
                price = "৪৯৯",
                features = listOf(
                    "আনলিমিটেড দৈনিক AI কন্টেন্ট জেনারেশন",
                    "সকল প্রিমিয়াম ও সাধারণ ফিচার আনলকড",
                    "সম্পূর্ণ আনব্রান্ডেড লং-ফর্ম কন্টেন্ট জেনারেশন",
                    "ইনস্ট্যান্ট কাস্টমার সাকসেস ম্যানেজার কোঅর্ডিনেশন",
                    "সর্বোচ্চ হাই-স্পিড রিসোর্স এলোকেশন"
                )
            )
        )

        packages.forEach { p ->
            val isCurrentPlan = plan == p.id

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("package_card_${p.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrentPlan) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(
                    width = if (isCurrentPlan) 2.dp else 1.dp,
                    color = if (isCurrentPlan) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (isCurrentPlan) 4.dp else 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (isCurrentPlan) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .background(
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Checked",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "আপনার বর্তমান প্যাকেজ",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Column {
                        Text(
                            text = p.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = p.desc,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = "৳" + p.price,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCurrentPlan) MaterialTheme.colorScheme.primary else Color.Black
                        )
                        Text(
                            text = " / মাস",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Features Bullets
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        p.features.forEach { feat ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Feature Bullet",
                                    tint = if (p.id == "free") Color.LightGray else BanglaGoldAccent,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = feat,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }

                    // Main Upgrade Button
                    if (isCurrentPlan) {
                        Button(
                            onClick = {},
                            enabled = false,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            colors = ButtonDefaults.buttonColors(
                                disabledContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                disabledContentColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text("✓ চলমান রয়েছে", fontWeight = FontWeight.Bold)
                        }
                    } else if (p.id == "free") {
                        OutlinedButton(
                            onClick = { viewModel.upgradePlan("free") },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Text("ফ্রি প্যাকেজে ফিরে যান", fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Button(
                            onClick = {
                                selectedPlanToBuy = p.id
                                priceToBuy = p.price
                                showPaymentDialog = true
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("upgrade_btn_${p.id}"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (p.id == "pro") BanglaGoldAccent else MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text("বিকাশ (bKash) দিয়ে আপগ্রেড", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showPaymentDialog) {
        PaymentSimDialog(
            planName = selectedPlanToBuy.uppercase(),
            price = priceToBuy,
            onDismissString = { showPaymentDialog = false },
            onPaymentSuccess = { planBought ->
                viewModel.upgradePlan(planBought)
                showPaymentDialog = false
            }
        )
    }
}

data class SubscriptionPackage(
    val id: String,
    val title: String,
    val desc: String,
    val price: String,
    val features: List<String>
)
