package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_content")
data class SavedContent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val featureName: String, // caption, hashtags, description, youtube, adcopy, blog
    val topic: String, // input prompt/topic
    val resultText: String, // generated content
    val timestamp: Long = System.currentTimeMillis()
)
