package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BkashPink = Color(0xFFE2136E)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentSimDialog(
    planName: String,
    price: String,
    onDismissString: () -> Unit,
    onPaymentSuccess: (String) -> Unit
) {
    var step by remember { mutableStateOf(1) } // 1: Number, 2: OTP, 3: PIN, 4: Verifying
    var bkashNum by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var isVerifying by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = { if (!isVerifying) onDismissString() }) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("bkash_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
            ) {
                // bKash Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BkashPink)
                        .padding(12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "bKash checkout",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Bangla AI BD - $planName",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (!isVerifying) {
                        IconButton(
                            onClick = onDismissString,
                            modifier = Modifier.align(Alignment.CenterEnd)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Checkout",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Price Badge
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFFF0F5))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "প্রদেয় অর্থ:",
                        color = Color.Black,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "৳$price BDT",
                        color = BkashPink,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                // Input and Steps Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (step) {
                        1 -> {
                            Text(
                                text = "আপনার বিকাশ একাউন্ট নাম্বার দিন",
                                color = Color.Gray,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = bkashNum,
                                onValueChange = { if (it.length <= 11) bkashNum = it },
                                placeholder = { Text("e.g. 017XXXXXXXX") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BkashPink,
                                    focusedLabelColor = BkashPink
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("bkash_number_input")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { if (bkashNum.length == 11) step = 2 },
                                enabled = bkashNum.length == 11,
                                colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("bkash_confirm_number_button")
                            ) {
                                Text("পরবর্তী (Next)", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        2 -> {
                            Text(
                                text = "বিকাশ ভেরিফিকেশন কোড (OTP)",
                                color = Color.Gray,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Text(
                                text = "আপনার নাম্বার 017* এ প্রেরিত ওটিপি দিন (যেকোনো ৬ সংখ্যা)",
                                color = Color.LightGray,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = otp,
                                onValueChange = { if (it.length <= 6) otp = it },
                                placeholder = { Text("6-Digit OTP") },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BkashPink
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("bkash_otp_input")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { if (otp.length == 6) step = 3 },
                                enabled = otp.length == 6,
                                colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("bkash_confirm_otp_button")
                            ) {
                                Text("যাচাই করুন (Confirm)", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        3 -> {
                            Text(
                                text = "বিকাশ একাউন্ট পিন (PIN) দিন",
                                color = Color.Gray,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = pin,
                                onValueChange = { if (it.length <= 5) pin = it },
                                placeholder = { Text("5-Digit PIN") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BkashPink
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("bkash_pin_input")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (pin.length >= 4) {
                                        isVerifying = true
                                        step = 4
                                        scope.launch {
                                            delay(2500) // Simulate secure validation delay
                                            onPaymentSuccess(planName.lowercase())
                                            onDismissString()
                                        }
                                    }
                                },
                                enabled = pin.length >= 4,
                                colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("bkash_confirm_pin_button")
                            ) {
                                Text("পেমেন্ট সম্পন্ন করুন", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        4 -> {
                            CircularProgressIndicator(
                                color = BkashPink,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "বিকাশ পেমেন্ট যাচাই করা হচ্ছে...",
                                fontWeight = FontWeight.SemiBold,
                                color = BkashPink,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "দয়া করে অপেক্ষা করুন, উইন্ডোটি বন্ধ করবেন না।",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Safe checkout banner
                    Text(
                        text = "🔒 Secure checkout with bKash API 2.0",
                        color = Color.LightGray,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
