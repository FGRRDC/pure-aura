package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bespoke Bangladeshi Brand Colors (Emerald & Gold)
val BanglaGreenPrimary = Color(0xFF028A61) // Rich vibrant emerald
val BanglaGreenDark = Color(0xFF005F41)
val BanglaGoldAccent = Color(0xFFF59E0B) // Bright warm gold
val BanglaTealLight = Color(0xFF10B981) // Active glowing teal

// Dark System Scheme Colors
val DarkBg = Color(0xFF0A120E) // Very eye-friendly deep rich forest-charcoal
val DarkSurface = Color(0xFF121E19) // Layered card depth
val DarkOnSurface = Color(0xFFECFDEC) // Clean near-white text with a green tint
val DarkPrimary = Color(0xFF34D399) // Bright teal-green for dark mode contrast
val DarkSecondary = Color(0xFF059669)

// Light System Scheme Colors
val LightBg = Color(0xFFF3FAF6) // Beautiful fresh minty light gray
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0A2118) // Rich off-black slate green for gorgeous contrast
val LightPrimary = Color(0xFF028A61)
val LightSecondary = Color(0xFF10B981)
