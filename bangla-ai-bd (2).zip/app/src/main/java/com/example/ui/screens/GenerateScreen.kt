package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BanglaGoldAccent
import com.example.ui.theme.BanglaGreenPrimary
import com.example.ui.theme.BanglaTealLight
import com.example.ui.viewmodel.BanglaAiViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun GenerateScreen(viewModel: BanglaAiViewModel) {
    val context = LocalContext.current
    val selectedFeature by viewModel.selectedFeature.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val lastGeneratedText by viewModel.lastGeneratedText.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val userConfig by viewModel.userConfig.collectAsState()

    // Premium Fields
    val premiumTone by viewModel.premiumTone.collectAsState()
    val premiumTargetAudience by viewModel.premiumTargetAudience.collectAsState()
    val blogType by viewModel.blogType.collectAsState()
    val blogWordCount by viewModel.blogWordCount.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("generate_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
            ),
            modifier = Modifier.fillMaxWidth().border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                shape = RoundedCornerShape(16.dp)
            )
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "🤖",
                    fontSize = 32.sp
                )
                Column {
                    Text(
                        text = "Bangla AI কন্টেন্ট রাইটার",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "বাংলাদেশী মার্কেট এবং অডিয়েন্সের জন্য কাস্টম AI কপিরাইটিং অ্যাসিস্ট্যান্ট",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }

        // Feature Chooser Buttons Grid
        Text(
            text = "রাইটিং টুল সিলেক্ট করুন:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 3
        ) {
            val features = listOf(
                FeatureItem("caption", "📘 ক্যাপশন", false),
                FeatureItem("hashtags", "🏷️ হ্যাশট্যাগ", false),
                FeatureItem("description", "📦 বিবরণী", false),
                FeatureItem("youtube", "🎬 টাইটেল", false),
                FeatureItem("adcopy", "💎 অ্যাড কপি", true),
                FeatureItem("blog", "📝 ব্লগ রাইটার", true)
            )

            features.forEach { feature ->
                val isSelected = selectedFeature == feature.id
                val plan = userConfig?.subscriptionPlan ?: "free"
                val shouldShowPremiumTag = feature.isPremium && plan == "free"

                FilterChip(
                    selected = isSelected,
                    onClick = {
                        viewModel.selectedFeature.value = feature.id
                        // Clear past state on change to keep workspace clean
                    },
                    label = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = feature.label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                            if (shouldShowPremiumTag) {
                                Badge(
                                    containerColor = BanglaGoldAccent,
                                    contentColor = Color.White,
                                    modifier = Modifier.padding(start = 2.dp)
                                ) {
                                    Text("PRO", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        labelColor = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.testTag("chip_${feature.id}")
                )
            }
        }

        Divider(color = MaterialTheme.colorScheme.outlineVariant)

        // Fields Header
        Text(
            text = "কন্টেন্ট বিবরণী",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        // Dynamic Input Placeholder based on feature
        val currentPlaceholder = when (selectedFeature) {
            "caption" -> "যেমন: একটি নতুন সুস্বাদু কাচ্চি বিরিয়ানি রেস্টুরেন্টের ফেসবুক বিজ্ঞাপনের জন্য..."
            "hashtags" -> "যেমন: বাংলাদেশী ট্রাভেল ভ্লগিং বা ফুড রিভিউ পোস্ট..."
            "description" -> "যেমন: রিচ কটন প্রিমিয়াম পাঞ্জাবি (বাংলাদেশী ক্রেতাদের জন্য বিবরণী)..."
            "youtube" -> "যেমন: কিভাবে অল্প টাকা দিয়ে কাস্টম গেমিং পিসি বিল্ড করবেন..."
            "adcopy" -> "যেমন: সোলার হোম এনার্জি ডিস্ট্রিবিউটর সিস্টেম প্রিমিয়াম অফার বিক্রি..."
            "blog" -> "যেমন: বাংলাদেশে স্টার্টআপ ব্যবসার অপার সম্ভাবনা ও সম্ভাবনা জেনারেট..."
            else -> "এখানে আপনার আইডিয়া বিস্তারিত লিখুন..."
        }

        OutlinedTextField(
            value = inputText,
            onValueChange = { viewModel.inputText.value = it },
            placeholder = { Text(currentPlaceholder, fontSize = 13.sp) },
            label = { Text("মূল বিষয়বস্তু / প্রোডাক্টের নাম", fontSize = 13.sp) },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .testTag("source_input_text"),
            maxLines = 4,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
        )

        // Dynamic Premium Sub-features input
        AnimatedVisibility(
            visible = selectedFeature == "adcopy",
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = premiumTone,
                        onValueChange = { viewModel.premiumTone.value = it },
                        modifier = Modifier.weight(1f).testTag("premium_tone_input"),
                        label = { Text("মিউজিক বা টোন", fontSize = 11.sp) },
                        placeholder = { Text("আকর্ষণীয় ও প্রফেশনাল") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = premiumTargetAudience,
                        onValueChange = { viewModel.premiumTargetAudience.value = it },
                        modifier = Modifier.weight(1f).testTag("premium_audience_input"),
                        label = { Text("টার্গেট অডিয়েন্স", fontSize = 11.sp) },
                        placeholder = { Text("তরুণ উদ্যোক্তা / ব্যবসায়ী") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = selectedFeature == "blog",
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Type Selector
                    Box(modifier = Modifier.weight(1f)) {
                        var dropdownExpanded by remember { mutableStateOf(false) }
                        OutlinedTextField(
                            value = when (blogType) {
                                "blog" -> "📝 ব্লগ পোস্ট"
                                "script" -> "🎬 ویڈیو স্ক্রিপ্ট"
                                else -> "📋 আর্টিকেল"
                            },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ফরম্যাট", fontSize = 11.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dropdownExpanded = true }
                                .testTag("premium_blog_type_input"),
                            trailingIcon = {
                                Icon(Icons.Default.ArrowDropDown, "dropdown",
                                    Modifier.clickable { dropdownExpanded = true })
                            },
                            shape = RoundedCornerShape(10.dp)
                        )
                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("📝 ব্লগ পোস্ট") },
                                onClick = {
                                    viewModel.blogType.value = "blog"
                                    dropdownExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🎬 ইউটিউব স্ক্রিপ্ট") },
                                onClick = {
                                    viewModel.blogType.value = "script"
                                    dropdownExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("📋 SEO আর্টিকেল") },
                                onClick = {
                                    viewModel.blogType.value = "article"
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = blogWordCount,
                        onValueChange = { viewModel.blogWordCount.value = it },
                        modifier = Modifier.weight(1f).testTag("premium_wordcount_input"),
                        label = { Text("শব্দ সংখ্যা", fontSize = 11.sp) },
                        placeholder = { Text("৫০০ শব্দ") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        // Generate Action Button
        Button(
            onClick = { viewModel.generateContent() },
            enabled = !isGenerating && inputText.isNotEmpty(),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            if (isGenerating) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("⚡ জেনারেট হচ্ছে...", fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.Edit, contentDescription = "Spark", Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                val btnLabel = if (selectedFeature == "adcopy" || selectedFeature == "blog") {
                    "✨ প্রিমিয়াম রাইট করুন (PRO)"
                } else {
                    "✨ কন্টেন্ট জেনারেট করুণ"
                }
                Text(btnLabel, fontWeight = FontWeight.Bold)
            }
        }

        // Error message panel
        if (errorMessage.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().testTag("error_card")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = errorMessage,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Output Copy Panel
        AnimatedVisibility(
            visible = lastGeneratedText.isNotEmpty() && !isGenerating,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✍️ জেনারেটেড কন্টেন্ট:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Generated Content", lastGeneratedText)
                                clipboard.setPrimaryClip(clip)
                                viewModel.triggerToast("টেক্সট ক্লিপবোর্ডে কপি করা হয়েছে!")
                            },
                            modifier = Modifier.testTag("copy_button")
                        ) {
                            Icon(Icons.Default.Share, "Copy", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                viewModel.saveContentLocally(selectedFeature, inputText, lastGeneratedText)
                            },
                            modifier = Modifier.testTag("save_button")
                        ) {
                            Icon(Icons.Default.Favorite, "Save", tint = BanglaGoldAccent)
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("output_container"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = lastGeneratedText,
                        modifier = Modifier.padding(16.dp),
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

data class FeatureItem(
    val id: String,
    val label: String,
    val isPremium: Boolean
)
